import random


def build_check_code(ts, order_id):
    random.seed(ts ^ order_id)
    return "".join(str(random.randint(0, 9)) for _ in range(6))


def obfuscate(secret, ts, order_id):
    random.seed(ts ^ order_id)
    _ = build_check_code(ts, order_id)
    mask = bytes(random.randint(0, 255) for _ in range(len(secret)))
    return bytes(ch ^ mask[i] for i, ch in enumerate(secret))
