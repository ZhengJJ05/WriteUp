from math import gcd


def crt_sign(message, dp, dq, p, q, inject_fault=False):
    sp = pow(message, dp, p)
    sq = pow(message, dq, q)
    if inject_fault:
        sq = (sq + 1) % q
    qinv = pow(q, -1, p)
    return sq + ((qinv * (sp - sq)) % p) * q
